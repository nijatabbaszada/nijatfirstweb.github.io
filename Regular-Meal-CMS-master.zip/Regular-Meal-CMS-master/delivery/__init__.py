default_app_config = 'delivery.apps.DeliveryConfig'
