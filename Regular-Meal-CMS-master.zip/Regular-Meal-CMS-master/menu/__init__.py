default_app_config = 'menu.apps.MenuConfig'
